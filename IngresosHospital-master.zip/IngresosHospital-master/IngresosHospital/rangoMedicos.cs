﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IngresosHospital
{
    public class rangoMedicos
    {
        public string nombreMedico { get; set; }
        public string apellidoMedico { get; set; }
        public DateTime fechaMedico { get; set; }
    }
}
