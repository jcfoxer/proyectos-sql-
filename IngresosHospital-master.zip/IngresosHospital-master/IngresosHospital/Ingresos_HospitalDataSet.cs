﻿namespace IngresosHospital
{


    partial class Ingresos_HospitalDataSet
    {
    }
}
