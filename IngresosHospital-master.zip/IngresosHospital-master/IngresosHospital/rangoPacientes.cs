﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IngresosHospital
{
    public class rangoPacientes
    {
        public string nombrePaciente { get; set; }
        public string apellidoPaciente { get; set; }
        public DateTime fechaPaciente { get; set; }
    }
}
